// gallery.js 
document.addEventListener("DOMContentLoaded", function() {

  const pics = document.querySelectorAll('.item img, .shoe img');
  
  if (pics.length === 0) return;

  let index = 0;
  let box = null;

  function show(index) {
    if (!box) {
      box = document.createElement('div');
      box.style.cssText = 'position:fixed;top:0;left:0;width:100vw;height:100vh;background:#000;display:flex;justify-content:center;align-items:center;z-index:999999;';
      box.innerHTML = `
        <div style="position:absolute;top:20px;right:30px;color:#ffde59;font-size:60px;cursor:pointer;font-weight:bold;">×</div>
        <div style="position:absolute;left:30px;top:50%;transform:translateY(-50%);color:#ffde59;font-size:70px;cursor:pointer;font-weight:bold;"><</div>
        <div style="position:absolute;right:30px;top:50%;transform:translateY(-50%);color:#ffde59;font-size:70px;cursor:pointer;font-weight:bold;">></div>
        <img src="" style="max-width:94%;max-height:94vh;object-fit:contain;border-radius:20px;">
      `;
      document.body.appendChild(box);

      box.children[0].onclick = () => box.style.display = 'none';
      box.children[1].onclick = (e) => { e.stopPropagation(); index = (index - 1 + pics.length) % pics.length; box.querySelector('img').src = pics[index].src; };
      box.children[2].onclick = (e) => { e.stopPropagation(); index = (index + 1) % pics.length; box.querySelector('img').src = pics[index].src; };
      box.onclick = (e) => { if (e.target === box) box.style.display = 'none'; };

      // swipe works perfect on phone
      let start = 0;
      box.addEventListener('touchstart', e => start = e.touches[0].clientX);
      box.addEventListener('touchend', e => {
        let diff = start - e.changedTouches[0].clientX;
        if (Math.abs(diff) > 50) {
          index = diff > 0 ? (index + 1) % pics.length : (index - 1 + pics.length) % pics.length;
          box.querySelector('img').src = pics[index].src;
        }
      });
    }

    box.style.display = 'flex';
    box.querySelector('img').src = pics[index].src;
  current = index;
  }

  pics.forEach((p, i) => {
    p.style.cursor = 'zoom-in';
    p.onclick = (e) => {
      e.preventDefault();
      show(i);
    };
  });
});