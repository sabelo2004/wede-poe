// gallery js - click picture it opens big and swipe left right on phone - sabelo
const allPics = document.querySelectorAll('.item img, .shoe img');
let current = 0;
let lightbox;

function openBig(n) {
  current = n;
  if (!lightbox) {
    lightbox = document.createElement('div');
    lightbox.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.95);display:flex;justify-content:center;align-items:center;z-index:9999;';
    lightbox.innerHTML = `<span style="position:absolute;top:20px;right:30px;color:#ffde59;font-size:50px;cursor:pointer;">×</span>
                         <span style="position:absolute;left:30px;top:50%;transform:translateY(-50%);color:#ffde59;font-size:60px;cursor:pointer;">‹</span>
                         <span style="position:absolute;right:30px;top:50%;transform:translateY(-50%);color:#ffde59;font-size:60px;cursor:pointer;">›</span>
                         <img src="" style="max-width:90%;max-height:85vh;border-radius:15px;box-shadow:0 0 40px #ffde59;">`;
    document.body.appendChild(lightbox);
    lightbox.children[0].onclick = () => lightbox.style.display = 'none';
    lightbox.children[1].onclick = (e) => { e.stopPropagation(); current = (current - 1 + allPics.length) % allPics.length; lightbox.querySelector('img').src = allPics[current].src; };
    lightbox.children[2].onclick = (e) => { e.stopPropagation(); current = (current + 1) % allPics.length; lightbox.querySelector('img').src = allPics[current].src; };
    lightbox.onclick = (e) => { if (e.target === lightbox) lightbox.style.display = 'none'; };
    
    // swipe for phone
    let startX = 0;
    lightbox.addEventListener('touchstart', e => startX = e.touches[0].clientX);
    lightbox.addEventListener('touchend', e => {
      let diff = startX - e.changedTouches[0].clientX;
      if (Math.abs(diff) > 50) {
        current = diff > 0 ? (current + 1) % allPics.length : (current - 1 + allPics.length) % allPics.length;
        lightbox.querySelector('img').src = allPics[current].src;
      }
    });
  }
  lightbox.style.display = 'flex';
  lightbox.querySelector('img').src = allPics[n].src;
}

allPics.forEach((pic, i) => pic.onclick = () => openBig(i));