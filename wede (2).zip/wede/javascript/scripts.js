// external js for both forms - sabelo
function sendEnquiry(e) {
  e.preventDefault();
  if (!document.getElementById('enquiryForm').checkValidity()) {
    document.getElementById('enquiryError').style.display = 'block';
    return;
  }
  emailjs.send("service_yz6a1on", "template_enquiry", {
    name: document.forms["enquiryForm"]["name"].value,
    email: document.forms["enquiryForm"]["email"].value,
    phone: document.forms["enquiryForm"]["phone"].value,
    interest: document.forms["enquiryForm"]["interest"].value,
    message: document.forms["enquiryForm"]["message"].value
  }).then(() => {
    document.getElementById('enquirySuccess').style.display = 'block';
    document.getElementById('enquiryForm').reset();
  });
}

function sendContact(e) {
  e.preventDefault();
  if (!document.getElementById('contactForm').checkValidity()) {
    document.getElementById('contactError').style.display = 'block';
    return;
  }
  emailjs.send("service_yz6a1on", "template_contact", {
    name: document.forms["contactForm"]["name"].value,
    email: document.forms["contactForm"]["email"].value,
    subject: document.forms["contactForm"]["subject"].value,
    message: document.forms["contactForm"]["message"].value
  }).then(() => {
    document.getElementById('contactSuccess').style.display = 'block';
    document.getElementById('contactForm').reset();
  });
}