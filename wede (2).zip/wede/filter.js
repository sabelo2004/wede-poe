// search bar for products - type nike or r300 it shows only those items
document.addEventListener("DOMContentLoaded", function() {
  var box = document.createElement("input");
  box.type = "text";
  box.placeholder = "search products... nike, r300, bag, hoodie, gucci, cup etc";
  box.style.cssText = "width:95%;padding:18px;margin:30px auto;display:block;font-size:20px;border:none;border-radius:15px;background:#000;color:#ffde59;text-align:center;box-shadow:0 0 30px #ffde59;";
  
  box.onkeyup = function() {
    var val = this.value.toLowerCase();
    document.querySelectorAll(".item, .shoe").forEach(function(el) {
      el.style.display = el.textContent.toLowerCase().includes(val) ? "" : "none";
    });
  };
  
  document.body.insertBefore(box, document.body.firstChild);
});